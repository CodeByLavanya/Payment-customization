import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

export async function action({ request }) {
  console.log(">>> /webhooks/orders/create action HIT");

  try {
    const { topic, shop, payload } = await authenticate.webhook(request);
    console.log(">>> Webhook authenticated");
    console.log(">>> Topic:", topic);
    console.log(">>> Shop:", shop);
  } catch (error) {
    if (error instanceof Response) {
      console.error(
        ">>> authenticate.webhook rejected request:",
        error.status,
        error.statusText,
      );
    } else {
      console.error(">>> Webhook auth error:", error);
    }
  }

  return json({ ok: true });
}
