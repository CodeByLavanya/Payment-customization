import { Layout, Card, BlockStack, Text } from "@shopify/polaris";
import Settings from "./app.setting";

export default function Index() {
  return (
    <s-page heading="Shopify app template">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="400">
              <Text as="h2" variant="headingMd">
                Checkout payment rules
              </Text>
              <Settings />
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </s-page>
  );
}
