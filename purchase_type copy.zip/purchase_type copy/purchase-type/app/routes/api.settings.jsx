import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

export async function action({ request }) {
  const { admin } = await authenticate.admin(request);

  const body = await request.json();
  const shopResponse = await admin.graphql(`
    query {
      shop {
        id
      }
    }
  `);

  const shopData = await shopResponse.json();
  const shopGid = shopData.data.shop.id;
  // console.log("Shop GID:", shopGid);

  const value = JSON.stringify({
    hide_cod_for_subscription: body.hide_cod_for_subscription === true,
    rename_bogus_for_otp: body.rename_bogus_for_otp === true,
  });
  const response = await admin.graphql(
    `mutation SetPaymentConfig($input: MetafieldsSetInput!) {
      metafieldsSet(metafields: [$input]) {
        metafields {
          id
          namespace
          key
          value
        }
        userErrors {
          field
          message
        }
      }
    }`,
    {
      variables: {
        input: {
          ownerId: shopGid,
          namespace: "payment-customization",
          key: "function-configuration",
          type: "json",
          value: value,
        },
      },
    },
  );

  const data = await response.json();
  // console.log("GraphQL Response:", JSON.stringify(data, null, 2));

  if (data.errors) {
    // console.log("GraphQL Errors:", data.errors);
    return json({ success: false, errors: data.errors }, { status: 400 });
  }

  if (data.data.metafieldsSet.userErrors.length > 0) {
    // console.log("User Errors:", data.data.metafieldsSet.userErrors);
    return json(
      { success: false, errors: data.data.metafieldsSet.userErrors },
      { status: 400 },
    );
  }
  return json({
    success: true,
    metafield: data.data.metafieldsSet.metafields[0],
  });
}
