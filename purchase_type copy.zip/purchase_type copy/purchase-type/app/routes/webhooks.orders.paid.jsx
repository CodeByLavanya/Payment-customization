// app/routes/webhooks.orders.paid.jsx
import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

console.log(">>> webhooks.orders.paid.jsx module loaded");

export async function loader() {
  return json({ message: "orders/paid webhook endpoint" });
}
export async function action({ request }) {
  console.log(">>> /webhooks/orders/paid action HIT");

  try {
    const { topic, shop, payload } = await authenticate.webhook(request);

    console.log(">>> Webhook authenticated");
    console.log(">>> Topic:", topic);
    console.log(">>> Shop:", shop);

    const order = payload;

    const orderId = order.id;
    const paymentMethod =
      order.payment_gateway_names?.[0] || order.gateway || "unknown";
    const paymentStatus = order.financial_status;

    let otpItemCount = 0;
    let subscriptionItemCount = 0;

    for (const line of order.line_items || []) {
      const purchaseTypeAttr = (line.properties || []).find(
        (p) => p.name === "purchase_type",
      );
      const purchaseType = purchaseTypeAttr?.value || null;

      const isOtpItem = purchaseType === "one-time-purchase";
      const isSubscriptionItem = purchaseType === "subscription";

      if (isOtpItem) otpItemCount += line.quantity;
      if (isSubscriptionItem) subscriptionItemCount += line.quantity;
    }

    console.log("[orders/paid webhook]");
    console.log("Order ID:", orderId);
    console.log("Payment method:", paymentMethod);
    console.log("OTP item count:", otpItemCount);
    console.log("Subscription item count:", subscriptionItemCount);
    console.log("Payment status:", paymentStatus);
  } catch (error) {
    console.log(
      ">>> Not a valid Shopify webhook (or auth failed):",
      error?.message,
    );
  }

  return json({ ok: true });
}
