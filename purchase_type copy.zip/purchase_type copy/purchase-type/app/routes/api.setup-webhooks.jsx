import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

export async function action({ request }) {
  console.log(">>> /api/setup-webhooks called");

  const authResult = await authenticate.admin(request);
  console.log(">>> authenticate.admin result:", {
    shop: authResult?.session?.shop,
  });

  const { admin } = authResult;

  const mutation = `
    #graphql
    mutation CreateOrderWebhooks(
      $ordersCreateCallback: String!,
      $ordersPaidCallback: String!,
      $metafieldNamespaces: [String!]
    ) {
      ordersCreateWebhook: webhookSubscriptionCreate(
        topic: ORDERS_CREATE
        webhookSubscription: {
          uri: $ordersCreateCallback
          format: JSON
          metafieldNamespaces: $metafieldNamespaces
        }
      ) {
        webhookSubscription {
          id
          topic
          format
          uri
          metafieldNamespaces
        }
        userErrors {
          field
          message
        }
      }

      ordersPaidWebhook: webhookSubscriptionCreate(
        topic: ORDERS_PAID
        webhookSubscription: {
          uri: $ordersPaidCallback
          format: JSON
          metafieldNamespaces: $metafieldNamespaces
        }
      ) {
        webhookSubscription {
          id
          topic
          format
          uri
          metafieldNamespaces
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const response = await admin.graphql(mutation, {
    variables: {
      ordersCreateCallback: `${process.env.SHOPIFY_APP_URL}/webhooks/orders/create`,
      ordersPaidCallback: `${process.env.SHOPIFY_APP_URL}/webhooks/orders/paid`,
      metafieldNamespaces: ["custom"],
    },
  });

  const data = await response.json();
  console.log(">>> webhook setup response:", JSON.stringify(data, null, 2));

  return json(data);
}

export async function loader() {
  return json({ ok: true });
}
