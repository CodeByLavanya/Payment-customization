import {
  Page,
  Card,
  Checkbox,
  Button,
  Banner,
  BlockStack,
} from "@shopify/polaris";
import { useState } from "react";
import { authenticate } from "../shopify.server";
import "@shopify/polaris/build/esm/styles.css";

export async function loader({ request }) {
  await authenticate.admin(request);
  return null;
}

export default function Settings() {
  const [hideCOD, setHideCOD] = useState(true);
  const [renameBogus, setRenameBogus] = useState(true);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("info");

  const saveSettings = async () => {
    try {
      const payload = {
        hide_cod_for_subscription: hideCOD,
        rename_bogus_for_otp: renameBogus,
      };

      // console.log("Sending data:", payload);
      setMessage("Saving...");
      setMessageType("info");

      const response = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const result = await response.json();
      console.log("Response:", result);

      if (result.success) {
        setMessage("Settings saved successfully!");
        setMessageType("success");
      } else {
        setMessage("Error: " + JSON.stringify(result.errors));
        setMessageType("critical");
      }
    } catch (error) {
      // console.log("Save error:", error);
      setMessage("Error: " + error.message);
      setMessageType("critical");
    }
  };

  return (
    <Page title="Payment Rules">
      {message && <Banner status={messageType}>{message}</Banner>}

      <BlockStack gap="400">
        <Card>
          <BlockStack gap="400">
            <Checkbox
              label="Hide Cash on Delivery for Subscription items"
              checked={hideCOD}
              onChange={setHideCOD}
            />
            <Checkbox
              label="Rename Bogus Gateway for OTP"
              checked={renameBogus}
              onChange={setRenameBogus}
            />
            <Button primary onClick={saveSettings}>
              Save Settings
            </Button>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
